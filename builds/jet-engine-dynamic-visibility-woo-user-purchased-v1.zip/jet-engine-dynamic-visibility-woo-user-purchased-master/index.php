<?php
// Silence in golden.
